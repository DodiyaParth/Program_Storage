from django.apps import AppConfig


class TariffConfig(AppConfig):
    name = 'tariff'
