from django.apps import AppConfig


class CarpositionConfig(AppConfig):
    name = 'carposition'
