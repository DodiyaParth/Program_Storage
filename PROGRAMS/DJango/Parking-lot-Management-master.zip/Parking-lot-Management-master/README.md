# Parking-lot-Management
A website to allow users to book and Admin to manage parking lot of a city/area.

# dependcy
1. Django (2.1.2)
2. django-queryset-csv (1.0.1)
3. django-suit (0.2.26)
4. python3
# usages
```
python manage.py migrate

python manage.py runserver
